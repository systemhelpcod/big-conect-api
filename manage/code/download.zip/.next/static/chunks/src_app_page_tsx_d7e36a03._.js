(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c8219e67._.js",
  "static/chunks/node_modules_1ace4c6a._.js"
],
    source: "dynamic"
});
